var searchData=
[
  ['getbufstats_171',['getBufStats',['../classbadgerdb_1_1_buf_mgr.html#a93148e1af99f06f4f264d948920b7c1c',1,'badgerdb::BufMgr']]],
  ['getfreespace_172',['getFreeSpace',['../classbadgerdb_1_1_page.html#a6f8c9e50538db4d88306b77c214c09dd',1,'badgerdb::Page']]],
  ['getnextusedslot_173',['getNextUsedSlot',['../classbadgerdb_1_1_page_iterator.html#a9433759a0a85c4f362a0ef2d511d7014',1,'badgerdb::PageIterator']]],
  ['getrecord_174',['getRecord',['../classbadgerdb_1_1_page.html#aad81fa59b469866fbd260c8a640b579f',1,'badgerdb::Page']]]
];
