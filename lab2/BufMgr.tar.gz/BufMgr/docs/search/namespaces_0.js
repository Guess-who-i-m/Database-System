var searchData=
[
  ['badgerdb_146',['badgerdb',['../namespacebadgerdb.html',1,'']]]
];
