var searchData=
[
  ['slot_5fnumber_204',['slot_number',['../classbadgerdb_1_1_invalid_slot_exception.html#ae6dd92a56c42895de79fdc3b098ecd81',1,'badgerdb::InvalidSlotException::slot_number()'],['../classbadgerdb_1_1_slot_in_use_exception.html#a2b64aacb650d56655a911fad7d685e9c',1,'badgerdb::SlotInUseException::slot_number() const']]],
  ['slotinuseexception_205',['SlotInUseException',['../classbadgerdb_1_1_slot_in_use_exception.html#a8002f3e4053d69486277c8092a700b8a',1,'badgerdb::SlotInUseException']]],
  ['space_5favailable_206',['space_available',['../classbadgerdb_1_1_insufficient_space_exception.html#af409576f555ea5de34a0ea3fc56cabc8',1,'badgerdb::InsufficientSpaceException']]],
  ['space_5frequested_207',['space_requested',['../classbadgerdb_1_1_insufficient_space_exception.html#af0083642253c6c9ac497e3ce3a5d1689',1,'badgerdb::InsufficientSpaceException']]]
];
