var searchData=
[
  ['badbufferexception',['BadBufferException',['../classbadgerdb_1_1_bad_buffer_exception.html#a12495d77cdfa368545c8a4594f1f9127',1,'badgerdb::BadBufferException']]],
  ['badgerdbexception',['BadgerDbException',['../classbadgerdb_1_1_badger_db_exception.html#a07fd2bb076246dab5233c3ceebc4d3af',1,'badgerdb::BadgerDbException']]],
  ['begin',['begin',['../classbadgerdb_1_1_file.html#a32e94f392eb3740dd9eb9101b9e09d47',1,'badgerdb::File::begin()'],['../classbadgerdb_1_1_page.html#aa0fdb281074cd60cb1f1d6ea6d620772',1,'badgerdb::Page::begin()']]],
  ['bufferexceededexception',['BufferExceededException',['../classbadgerdb_1_1_buffer_exceeded_exception.html#ab15b1a0d0e13bd8a7d831f4943f744cf',1,'badgerdb::BufferExceededException']]],
  ['bufhashtbl',['BufHashTbl',['../classbadgerdb_1_1_buf_hash_tbl.html#a3928e864b3739c5772020c3eb3edec7c',1,'badgerdb::BufHashTbl']]],
  ['bufmgr',['BufMgr',['../classbadgerdb_1_1_buf_mgr.html#a18b7cf23b619c7c0e593d1dc45da77b4',1,'badgerdb::BufMgr']]],
  ['bufstats',['BufStats',['../structbadgerdb_1_1_buf_stats.html#ad9848260b3b787f15eb1b960b0f8e769',1,'badgerdb::BufStats']]]
];
