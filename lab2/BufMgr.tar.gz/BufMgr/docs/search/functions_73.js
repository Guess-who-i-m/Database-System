var searchData=
[
  ['slot_5fnumber',['slot_number',['../classbadgerdb_1_1_invalid_slot_exception.html#ad60c0b09c7dd6ff0dae875e6614a5f1d',1,'badgerdb::InvalidSlotException::slot_number()'],['../classbadgerdb_1_1_slot_in_use_exception.html#aeb8aba1320db5dba5fbd0eb64840b563',1,'badgerdb::SlotInUseException::slot_number()']]],
  ['slotinuseexception',['SlotInUseException',['../classbadgerdb_1_1_slot_in_use_exception.html#a8002f3e4053d69486277c8092a700b8a',1,'badgerdb::SlotInUseException']]],
  ['space_5favailable',['space_available',['../classbadgerdb_1_1_insufficient_space_exception.html#a097de7a441830920ebf2361f5011ada4',1,'badgerdb::InsufficientSpaceException']]],
  ['space_5frequested',['space_requested',['../classbadgerdb_1_1_insufficient_space_exception.html#ab201b99fc848898a0c8fb3ff0f284321',1,'badgerdb::InsufficientSpaceException']]]
];
