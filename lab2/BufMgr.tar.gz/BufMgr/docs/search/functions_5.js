var searchData=
[
  ['file_164',['File',['../classbadgerdb_1_1_file.html#a600baaf77d18f39e51ae7473eca633c4',1,'badgerdb::File']]],
  ['fileexistsexception_165',['FileExistsException',['../classbadgerdb_1_1_file_exists_exception.html#a127fc62de579ee20359d50aad560e60e',1,'badgerdb::FileExistsException']]],
  ['fileiterator_166',['FileIterator',['../classbadgerdb_1_1_file_iterator.html#a99bd5c0e0fac0493f9664409219ca88e',1,'badgerdb::FileIterator::FileIterator()'],['../classbadgerdb_1_1_file_iterator.html#ad286fc916be769b1bea154603b83ece0',1,'badgerdb::FileIterator::FileIterator(File *file)'],['../classbadgerdb_1_1_file_iterator.html#afabd7eecd315a85f9eb602f71c6f88e3',1,'badgerdb::FileIterator::FileIterator(File *file, PageId page_number)']]],
  ['filename_167',['filename',['../classbadgerdb_1_1_file_exists_exception.html#ac18efb4a600c843c3c6e3a20c91914a6',1,'badgerdb::FileExistsException::filename()'],['../classbadgerdb_1_1_file_not_found_exception.html#a42c86bdb20d593145171122b8d7625c0',1,'badgerdb::FileNotFoundException::filename()'],['../classbadgerdb_1_1_file_open_exception.html#ad5758410a91fe3c9014967f3ce4b8f48',1,'badgerdb::FileOpenException::filename()'],['../classbadgerdb_1_1_invalid_page_exception.html#ab2da9c8f8ccfd57ff34718fdf545ca2f',1,'badgerdb::InvalidPageException::filename()'],['../classbadgerdb_1_1_file.html#af16040a60f18c99305348077ac9e8aa8',1,'badgerdb::File::filename()']]],
  ['filenotfoundexception_168',['FileNotFoundException',['../classbadgerdb_1_1_file_not_found_exception.html#a53d52b9ecbd214bb5db7e9b3401248b8',1,'badgerdb::FileNotFoundException']]],
  ['fileopenexception_169',['FileOpenException',['../classbadgerdb_1_1_file_open_exception.html#af315ef5b756efe579a1b8ee7f6e4d352',1,'badgerdb::FileOpenException']]],
  ['flushfile_170',['flushFile',['../classbadgerdb_1_1_buf_mgr.html#acc61d1985720411ebb76e70f702827d3',1,'badgerdb::BufMgr']]]
];
