var indexSectionsWithContent =
{
  0: "abcdefghilmnoprsuvw~",
  1: "bfhiprs",
  2: "b",
  3: "abcdefghilmnoprsuw~",
  4: "abcdfimnprsuv",
  5: "fps",
  6: "o",
  7: "b"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "related",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Friends",
  7: "Pages"
};

