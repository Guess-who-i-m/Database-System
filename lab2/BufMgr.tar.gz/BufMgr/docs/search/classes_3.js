var searchData=
[
  ['insufficientspaceexception_134',['InsufficientSpaceException',['../classbadgerdb_1_1_insufficient_space_exception.html',1,'badgerdb']]],
  ['invalidpageexception_135',['InvalidPageException',['../classbadgerdb_1_1_invalid_page_exception.html',1,'badgerdb']]],
  ['invalidrecordexception_136',['InvalidRecordException',['../classbadgerdb_1_1_invalid_record_exception.html',1,'badgerdb']]],
  ['invalidslotexception_137',['InvalidSlotException',['../classbadgerdb_1_1_invalid_slot_exception.html',1,'badgerdb']]]
];
