var searchData=
[
  ['what_110',['what',['../classbadgerdb_1_1_badger_db_exception.html#a496fb41a623c1aad0131a6cd1319d416',1,'badgerdb::BadgerDbException']]],
  ['writepage_111',['writePage',['../classbadgerdb_1_1_file.html#a9a1b3cc43c4631bde58c1c4f670e1036',1,'badgerdb::File']]]
];
