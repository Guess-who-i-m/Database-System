var searchData=
[
  ['badbufferexception_117',['BadBufferException',['../classbadgerdb_1_1_bad_buffer_exception.html',1,'badgerdb']]],
  ['badgerdbexception_118',['BadgerDbException',['../classbadgerdb_1_1_badger_db_exception.html',1,'badgerdb']]],
  ['bufdesc_119',['BufDesc',['../classbadgerdb_1_1_buf_desc.html',1,'badgerdb']]],
  ['bufferexceededexception_120',['BufferExceededException',['../classbadgerdb_1_1_buffer_exceeded_exception.html',1,'badgerdb']]],
  ['bufhashtbl_121',['BufHashTbl',['../classbadgerdb_1_1_buf_hash_tbl.html',1,'badgerdb']]],
  ['bufmgr_122',['BufMgr',['../classbadgerdb_1_1_buf_mgr.html',1,'badgerdb']]],
  ['bufstats_123',['BufStats',['../structbadgerdb_1_1_buf_stats.html',1,'badgerdb']]]
];
