var searchData=
[
  ['what',['what',['../classbadgerdb_1_1_badger_db_exception.html#a2b13d988c95d0d180529fee8a25bed18',1,'badgerdb::BadgerDbException']]],
  ['writepage',['writePage',['../classbadgerdb_1_1_file.html#a9a1b3cc43c4631bde58c1c4f670e1036',1,'badgerdb::File']]]
];
