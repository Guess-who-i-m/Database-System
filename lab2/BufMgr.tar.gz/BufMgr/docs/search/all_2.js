var searchData=
[
  ['clear_14',['clear',['../structbadgerdb_1_1_buf_stats.html#a04a848e5458491fd3ea56133464cadbd',1,'badgerdb::BufStats']]],
  ['clearbufstats_15',['clearBufStats',['../classbadgerdb_1_1_buf_mgr.html#a702a264ae946b334414e51700edd81a0',1,'badgerdb::BufMgr']]],
  ['create_16',['create',['../classbadgerdb_1_1_file.html#a1fb708b45103a606f189850d6bf83a0c',1,'badgerdb::File']]],
  ['current_5fpage_5fnumber_17',['current_page_number',['../structbadgerdb_1_1_page_header.html#a3f721c5ce9ef491fdc9d12292f2f4498',1,'badgerdb::PageHeader']]]
];
