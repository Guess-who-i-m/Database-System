var searchData=
[
  ['hashalreadypresentexception_47',['HashAlreadyPresentException',['../classbadgerdb_1_1_hash_already_present_exception.html',1,'badgerdb::HashAlreadyPresentException'],['../classbadgerdb_1_1_hash_already_present_exception.html#a7fae22e4b34f7ed708c546af79abd11a',1,'badgerdb::HashAlreadyPresentException::HashAlreadyPresentException()']]],
  ['hashbucket_48',['hashBucket',['../structbadgerdb_1_1hash_bucket.html',1,'badgerdb']]],
  ['hashnotfoundexception_49',['HashNotFoundException',['../classbadgerdb_1_1_hash_not_found_exception.html',1,'badgerdb::HashNotFoundException'],['../classbadgerdb_1_1_hash_not_found_exception.html#aa49137bd55429a150dc7edb3cc7fb6e7',1,'badgerdb::HashNotFoundException::HashNotFoundException()']]],
  ['hashtableexception_50',['HashTableException',['../classbadgerdb_1_1_hash_table_exception.html',1,'badgerdb::HashTableException'],['../classbadgerdb_1_1_hash_table_exception.html#a3387d8a6ab4e263edd54bc4bdcf979ea',1,'badgerdb::HashTableException::HashTableException()']]],
  ['hasspaceforrecord_51',['hasSpaceForRecord',['../classbadgerdb_1_1_page.html#a059cb59e3ba05921f9c648fb5dba1068',1,'badgerdb::Page']]]
];
