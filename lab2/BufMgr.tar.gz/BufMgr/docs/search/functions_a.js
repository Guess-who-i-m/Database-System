var searchData=
[
  ['message_187',['message',['../classbadgerdb_1_1_badger_db_exception.html#a6eeb128b1b886ab84f5ba043127dcce1',1,'badgerdb::BadgerDbException']]]
];
