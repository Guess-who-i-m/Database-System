var searchData=
[
  ['readpage_201',['readPage',['../classbadgerdb_1_1_buf_mgr.html#a9f853f0f1d4628e7e14374d0c7c6a4f3',1,'badgerdb::BufMgr::readPage()'],['../classbadgerdb_1_1_file.html#a343b7fb1a238992f02454e9e81837acd',1,'badgerdb::File::readPage()']]],
  ['record_5fid_202',['record_id',['../classbadgerdb_1_1_invalid_record_exception.html#aedfc2f80234cd37d13a9bdde5e99fc5c',1,'badgerdb::InvalidRecordException']]],
  ['remove_203',['remove',['../classbadgerdb_1_1_buf_hash_tbl.html#a5739cc2b22c74d62e25c9d3d316144d8',1,'badgerdb::BufHashTbl::remove()'],['../classbadgerdb_1_1_file.html#a1cc69467366badbd68021ac76a91190e',1,'badgerdb::File::remove()']]]
];
