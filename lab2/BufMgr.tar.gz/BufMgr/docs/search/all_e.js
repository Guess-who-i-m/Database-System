var searchData=
[
  ['readpage_91',['readPage',['../classbadgerdb_1_1_buf_mgr.html#a9f853f0f1d4628e7e14374d0c7c6a4f3',1,'badgerdb::BufMgr::readPage()'],['../classbadgerdb_1_1_file.html#a343b7fb1a238992f02454e9e81837acd',1,'badgerdb::File::readPage()']]],
  ['record_5fid_92',['record_id',['../classbadgerdb_1_1_invalid_record_exception.html#aedfc2f80234cd37d13a9bdde5e99fc5c',1,'badgerdb::InvalidRecordException']]],
  ['record_5fid_5f_93',['record_id_',['../classbadgerdb_1_1_invalid_record_exception.html#af1a2e1ad376303aa5411b7d168634586',1,'badgerdb::InvalidRecordException']]],
  ['recordid_94',['RecordId',['../structbadgerdb_1_1_record_id.html',1,'badgerdb']]],
  ['refbit_95',['refbit',['../classbadgerdb_1_1_bad_buffer_exception.html#af871746d373d9a16e2203a783e06d00e',1,'badgerdb::BadBufferException']]],
  ['remove_96',['remove',['../classbadgerdb_1_1_buf_hash_tbl.html#a5739cc2b22c74d62e25c9d3d316144d8',1,'badgerdb::BufHashTbl::remove()'],['../classbadgerdb_1_1_file.html#a1cc69467366badbd68021ac76a91190e',1,'badgerdb::File::remove()']]]
];
