var searchData=
[
  ['recordid_144',['RecordId',['../structbadgerdb_1_1_record_id.html',1,'badgerdb']]]
];
