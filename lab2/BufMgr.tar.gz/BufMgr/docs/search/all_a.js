var searchData=
[
  ['message_64',['message',['../classbadgerdb_1_1_badger_db_exception.html#a6eeb128b1b886ab84f5ba043127dcce1',1,'badgerdb::BadgerDbException']]],
  ['message_5f_65',['message_',['../classbadgerdb_1_1_badger_db_exception.html#a4510b66828c819004489218abeb1cf32',1,'badgerdb::BadgerDbException']]]
];
