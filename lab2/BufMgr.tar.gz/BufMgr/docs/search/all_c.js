var searchData=
[
  ['open_73',['open',['../classbadgerdb_1_1_file.html#a8462afdbd250c0a483ddfbde144c8732',1,'badgerdb::File']]],
  ['operator_21_3d_74',['operator!=',['../structbadgerdb_1_1_record_id.html#abef1000678efe46ff7612f35c1e41e86',1,'badgerdb::RecordId']]],
  ['operator_2a_75',['operator*',['../classbadgerdb_1_1_file_iterator.html#ab251231092c7b7b6895b82f44c24e832',1,'badgerdb::FileIterator::operator*()'],['../classbadgerdb_1_1_page_iterator.html#a93b1d76b44cdd2a24cd9ed9f1904dafc',1,'badgerdb::PageIterator::operator*()']]],
  ['operator_2b_2b_76',['operator++',['../classbadgerdb_1_1_file_iterator.html#a6fa0f1cef8b46bb933ce6f000276ab52',1,'badgerdb::FileIterator::operator++()'],['../classbadgerdb_1_1_page_iterator.html#a2e63f3eea97170b2c566d1549a2215f0',1,'badgerdb::PageIterator::operator++()']]],
  ['operator_3c_3c_77',['operator&lt;&lt;',['../classbadgerdb_1_1_badger_db_exception.html#a06e373696437ef57bd3cf12041e0a420',1,'badgerdb::BadgerDbException']]],
  ['operator_3d_78',['operator=',['../classbadgerdb_1_1_file.html#ac403c631aec085e9f12992f260a57155',1,'badgerdb::File']]],
  ['operator_3d_3d_79',['operator==',['../structbadgerdb_1_1_file_header.html#ae1f662fea1e092100041c96be576f9d6',1,'badgerdb::FileHeader::operator==()'],['../classbadgerdb_1_1_file_iterator.html#a5eff20ca4457438dd7ba2a09ec87703a',1,'badgerdb::FileIterator::operator==()'],['../structbadgerdb_1_1_page_header.html#a57c325ad3552a01e24fcb01b415d7763',1,'badgerdb::PageHeader::operator==()'],['../classbadgerdb_1_1_page_iterator.html#a1e8953467bb28cf27eff09f9cdc0a16f',1,'badgerdb::PageIterator::operator==()'],['../structbadgerdb_1_1_record_id.html#a8558089af839ce3b345ab026a8fb1463',1,'badgerdb::RecordId::operator==()']]]
];
