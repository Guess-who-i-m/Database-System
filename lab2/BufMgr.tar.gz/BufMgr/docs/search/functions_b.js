var searchData=
[
  ['next_5fpage_5fnumber_188',['next_page_number',['../classbadgerdb_1_1_page.html#a9524d4507a600c1bd55bdc5b9511a484',1,'badgerdb::Page']]]
];
