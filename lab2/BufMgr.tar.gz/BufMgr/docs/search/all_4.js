var searchData=
[
  ['end_25',['end',['../classbadgerdb_1_1_file.html#a01e224676a67634f21d53fc4189b8f11',1,'badgerdb::File::end()'],['../classbadgerdb_1_1_page.html#a8e78cba69bef682a5427932485da4608',1,'badgerdb::Page::end()']]],
  ['exists_26',['exists',['../classbadgerdb_1_1_file.html#a864d59b12302c26b14967bd1d3e520bd',1,'badgerdb::File']]]
];
